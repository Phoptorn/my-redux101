const number = 1234567890

export const numberReducer = (state = number) => {
		return state
}