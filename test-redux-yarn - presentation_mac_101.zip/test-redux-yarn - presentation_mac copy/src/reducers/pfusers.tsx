const pfusers = [
    {
        id: '1',
        pf_user_Firstname: 'Name1',
        pf_user_Lastname: 'Sur1',
    },
    {
        id: '2',
        pf_user_Firstname: 'Name2',
        pf_user_Lastname: 'Sur2',
    },
    {
        id: '3',
        pf_user_Firstname: 'Name3',
        pf_user_Lastname: 'Sur3',
    },
]

export const pfusersReducer = (state = pfusers) => {
    return state
}