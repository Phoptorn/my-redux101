const string = "stringReducers"

export const stringReducer = (state = string) => {
	return state
}